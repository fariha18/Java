import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TreapTest {

	@Test
	void test() {
		Treap<Integer>testTree = new Treap <Integer>();
		assertTrue(testTree.add(4,19)); 
		assertTrue(testTree.add(2,31));
		assertTrue(testTree.add(6,70)); 
		assertTrue(testTree.add(1,84));
		assertTrue(testTree.add(3,12)); 
		assertTrue(testTree.add(5,83));
		assertTrue(testTree.add(7,26));
	}
	

}
