import java.util.Random;
import java.util.Stack;

//Fariha Rahman
//I pledge my honor that I have abided by the Stevens Honor System

public class Treap<E extends Comparable<E>>{

	
	private static class Node<E>{
	
		//Data Fields
		public E data; //key for the search
		public int priority; //random heap priority
		public Node <E>left;
		public Node <E>right;


		//Constructors
	public Node (E data , int priority){
 
		this.data = data;
		this.priority = priority;
		this.left = null;
		this.right = null;
 
		if(data == null){
			throw new IllegalArgumentException("Data is null");
		}
	}

	//Methods
	Node <E> rotateRight(){
	
		Node<E> first = this.left;
		Node<E> left = first.right;
		first.right = this;
		this.left = left;
		return first;
	}

	Node <E> rotateLeft (){
	
		Node<E> first = this.right;
		Node<E> right = first.left;
		first.left = this;
		this.right = right;
		return first;
	}
	}



	//Data Fields
	private Random priorityGenerator;
	private Node <E > root;

	//Constructors
	public Treap(){
		priorityGenerator = new Random();
		root = null;
	}

	public Treap(long seed){
		root = null;
		priorityGenerator = new Random(seed);
	}


	//Methods
	boolean add(E key){
		return add(key, priorityGenerator.nextInt());
	}

	public void reheap(Node<E> val, Stack<Node<E>> route){
		while (!route.isEmpty()){
			Node<E> parent = route.pop();
			
		if (parent.priority < val.priority){
			if (parent.data.compareTo(val.data) > 0){
				val = parent.rotateRight();
				} 
			
			else{
				val = parent.rotateLeft();
			}
			
			if (!route.isEmpty()){
				if (route.peek().left == parent){
					route.peek().left = val;
					} 
				
				else{
					route.peek().right = val;
					}
				}
			
			else{
				this.root = val;
				}
			}
		
		else{
			break;
		}
	}
	}

	boolean add(E key , int priority){
		
		if (root == null){
			root = new Node<E>(key, priority);
			return true;
		} 
		
		else{
			Stack<Node<E>> temp = new Stack<Node<E>>();
			Node<E> temp2 = new Node<E>(key, priority);
		
			Node<E> current = root;
		while (current != null){
			int compare = current.data.compareTo(key);
			
			if (compare == 0){
			return false;
			} 
			else{
				if (compare < 0){
					temp.push(current);
					if (current.right == null){
						current.right = temp2;
						reheap(temp2, temp);
						return true;
					} 
					
					else{
						current = current.right;
					}
				} 
				
				else{
					
					temp.push(current);
					if (current.left == null){
						current.left = temp2;
						reheap(temp2, temp);
						return true;
					} 
					
					else{
						current = current.left;
					}
				}
			}
		}
		return false;
	}
	}

	private Node<E> deletehelper(Node<E> current, E key){
		if (current == null) {
        return current;
		}
		
		if(key.compareTo(current.data) < 0){
        current.left = deletehelper(current.left, key);
        }  
		
		else if (current.left == null){
        Node<E> temp = current.right;
        current = temp;
        }
    
		else if (current.right == null){
        Node<E> temp = current.left;
        current = temp;
		}
		
		else if (key.compareTo(current.data) > 0){
        current.right = deletehelper(current.right, key);
		}
		
		else if (current.left.priority < current.right.priority){
        current = current.rotateLeft();
        current.left = deletehelper(current.left, key);
		} 
		
		else {
        current = current.rotateRight();
        current.right = deletehelper(current.right, key);
		}
		return current;
	}

	boolean delete( E key ){
		if(root == null) {
     	return false;
		}
		
		if(find(key)==false) {
         return false;
		}
		
		this.root = deletehelper(this.root, key);
		return true;
	}

	private boolean find( Node <E > root , E key ){
		while(root != null){
		if (key == root.data){
			return true;
		}
		
		else if (key.compareTo(root.data) < 0){
			root = root.left;
		}
		
		else {
			root = root.right;
		}
	}
		return false;
	}

	public boolean find(E key ){
		return find(root, key);
	}

	public void preOrderTraverse(Node<E> n, int depth, StringBuilder s) {
	
		for (int i = 1; i < depth; i++) {
        s.append("  ");
		}

		if (n == null) {
        s.append("null\n");
		} 
		
		else {
        s.append(n.toString());
        s.append("\n");
        preOrderTraverse(n.left, depth + 1, s);
        preOrderTraverse(n.right, depth + 1, s);

    }
	}
	
	public String toString (){  
		StringBuilder sb = new StringBuilder();
		preOrderTraverse(root, 1, sb);
		return sb.toString();

	}

	public static void main (String[] args) {

	}

	}